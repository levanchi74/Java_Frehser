package com.chile.data;

public class Data {
	public static String username = "admin";
	public static String password = "admin";
}
